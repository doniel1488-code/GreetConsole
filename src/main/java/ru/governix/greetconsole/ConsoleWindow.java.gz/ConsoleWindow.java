package ru.governix.greetconsole;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.io.IOException;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Native desktop log window. All Swing access is performed on the EDT. */
final class ConsoleWindow {
    private static final int MAX_HISTORY = 5_000;
    private static final Color BACKGROUND = new Color(12, 16, 25);
    private static final Color PANEL = new Color(20, 27, 40);
    private static final Color FOREGROUND = new Color(216, 225, 240);
    private static final Color MUTED = new Color(139, 153, 177);
    private static final Color DEFAULT_TEXT = new Color(208, 218, 235);

    private static final Color[] MINECRAFT_COLORS = {
            new Color(0x000000), new Color(0x0000AA), new Color(0x00AA00), new Color(0x00AAAA),
            new Color(0xAA0000), new Color(0xAA00AA), new Color(0xFFAA00), new Color(0xAAAAAA),
            new Color(0x555555), new Color(0x5555FF), new Color(0x55FF55), new Color(0x55FFFF),
            new Color(0xFF5555), new Color(0xFF55FF), new Color(0xFFFF55), new Color(0xFFFFFF)
    };

    private final List<LogLine> history = Collections.synchronizedList(new ArrayList<>());
    private final ConcurrentLinkedQueue<LogLine> pendingUiLines = new ConcurrentLinkedQueue<>();
    private final Map<LogLine.Level, JCheckBox> levelFilters = new EnumMap<>(LogLine.Level.class);

    private volatile JFrame frame;
    private JTextPane textPane;
    private JTextField searchField;
    private JLabel statusLabel;
    private JCheckBox autoScrollCheck;
    private JButton pauseButton;
    private volatile boolean paused;
    private volatile boolean windowVisible;
    private boolean uiUpdateScheduled;
    private String monospaceFont = "Monospaced";

    void addLine(String value) {
        if (value == null || value.isEmpty()) return;
        LogLine line = LogLine.from(value);
        synchronized (history) {
            history.add(line);
            while (history.size() > MAX_HISTORY) history.remove(0);
        }

        JFrame current = frame;
        if (current == null || !windowVisible || paused) return;
        pendingUiLines.add(line);
        scheduleUiDrain();
    }

    void toggle() {
        SwingUtilities.invokeLater(() -> {
            ensureWindow();
            if (frame.isVisible()) {
                frame.setVisible(false);
                windowVisible = false;
            } else {
                rebuildDocument();
                frame.setVisible(true);
                windowVisible = true;
                frame.toFront();
                frame.requestFocus();
            }
        });
    }

    void shutdown() {
        SwingUtilities.invokeLater(() -> {
            if (frame != null) {
                frame.dispose();
                frame = null;
                windowVisible = false;
            }
        });
    }

    private void ensureWindow() {
        if (frame != null) return;

        chooseFont();
        JFrame created = new JFrame("GreetConsole — Minecraft Log");
        try (var iconStream = ConsoleWindow.class.getResourceAsStream("/assets/greetconsole/icon.png")) {
            if (iconStream != null) {
                var icon = ImageIO.read(iconStream);
                if (icon != null) created.setIconImage(icon);
            }
        } catch (IOException ignored) {
            // The mod remains usable if a custom build omits the optional desktop icon.
        }
        created.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        created.setMinimumSize(new Dimension(720, 420));
        created.setSize(1120, 720);
        created.setLocationRelativeTo(null);
        created.getContentPane().setBackground(BACKGROUND);
        created.setLayout(new BorderLayout(0, 0));

        JPanel root = new JPanel(new BorderLayout(0, 8));
        root.setBackground(BACKGROUND);
        root.setBorder(BorderFactory.createEmptyBorder(12, 12, 10, 12));
        created.setContentPane(root);

        JPanel toolbar = new JPanel(new BorderLayout(8, 8));
        toolbar.setBackground(PANEL);
        toolbar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(48, 62, 86)),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));

        JPanel topLine = new JPanel(new BorderLayout(8, 0));
        topLine.setOpaque(false);
        JLabel title = new JLabel("GREETCONSOLE  /  LIVE LOG");
        title.setForeground(new Color(158, 176, 255));
        title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        topLine.add(title, BorderLayout.WEST);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        actions.setOpaque(false);
        pauseButton = createButton("Пауза", false);
        pauseButton.addActionListener(event -> togglePause());
        JButton clearButton = createButton("Очистить", false);
        clearButton.addActionListener(event -> clearHistory());
        JButton copyButton = createButton("Копировать", false);
        copyButton.addActionListener(event -> copyVisible());
        actions.add(pauseButton);
        actions.add(clearButton);
        actions.add(copyButton);
        topLine.add(actions, BorderLayout.EAST);
        toolbar.add(topLine, BorderLayout.NORTH);

        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        filters.setOpaque(false);
        for (LogLine.Level level : LogLine.Level.values()) {
            JCheckBox check = new JCheckBox(level.name());
            check.setOpaque(false);
            check.setForeground(colorForLevel(level));
            check.setSelected(true);
            check.setFocusable(false);
            check.addActionListener(event -> rebuildDocument());
            levelFilters.put(level, check);
            filters.add(check);
        }
        autoScrollCheck = new JCheckBox("Автопрокрутка", true);
        autoScrollCheck.setOpaque(false);
        autoScrollCheck.setForeground(FOREGROUND);
        filters.add(autoScrollCheck);
        toolbar.add(filters, BorderLayout.CENTER);

        JPanel searchRow = new JPanel(new BorderLayout(8, 0));
        searchRow.setOpaque(false);
        JLabel searchLabel = new JLabel("Поиск");
        searchLabel.setForeground(MUTED);
        searchRow.add(searchLabel, BorderLayout.WEST);
        searchField = new JTextField();
        searchField.setBackground(BACKGROUND);
        searchField.setForeground(FOREGROUND);
        searchField.setCaretColor(FOREGROUND);
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(55, 69, 94)),
                BorderFactory.createEmptyBorder(5, 8, 5, 8)));
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent event) { highlightSearch(); }
            @Override public void removeUpdate(DocumentEvent event) { highlightSearch(); }
            @Override public void changedUpdate(DocumentEvent event) { highlightSearch(); }
        });
        searchRow.add(searchField, BorderLayout.CENTER);
        toolbar.add(searchRow, BorderLayout.SOUTH);
        root.add(toolbar, BorderLayout.NORTH);

        textPane = new JTextPane();
        textPane.setEditable(false);
        textPane.setBackground(BACKGROUND);
        textPane.setForeground(DEFAULT_TEXT);
        textPane.setCaretColor(FOREGROUND);
        textPane.setFont(new Font(monospaceFont, Font.PLAIN, 13));
        textPane.setBorder(BorderFactory.createEmptyBorder(8, 9, 8, 9));
        JScrollPane scrollPane = new JScrollPane(textPane);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(48, 62, 86)));
        scrollPane.getViewport().setBackground(BACKGROUND);
        root.add(scrollPane, BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        JLabel pathLabel = new JLabel("Источник: .minecraft/logs/latest.log  •  F8 — показать/скрыть");
        pathLabel.setForeground(MUTED);
        pathLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
        statusLabel = new JLabel("LIVE");
        statusLabel.setForeground(new Color(92, 222, 160));
        statusLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 11));
        footer.add(pathLabel, BorderLayout.WEST);
        footer.add(statusLabel, BorderLayout.EAST);
        root.add(footer, BorderLayout.SOUTH);

        created.addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent event) {
                // HIDE_ON_CLOSE keeps the tailer and history alive.
                windowVisible = false;
            }
        });

        frame = created;
        rebuildDocument();
    }

    private void chooseFont() {
        try {
            List<String> available = List.of(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames());
            if (available.contains("Cascadia Mono")) monospaceFont = "Cascadia Mono";
            else if (available.contains("Consolas")) monospaceFont = "Consolas";
            else if (available.contains("DejaVu Sans Mono")) monospaceFont = "DejaVu Sans Mono";
        } catch (Exception ignored) {
            monospaceFont = "Monospaced";
        }
    }

    private JButton createButton(String text, boolean primary) {
        JButton button = new JButton(text);
        button.setFocusable(false);
        button.setForeground(primary ? Color.WHITE : FOREGROUND);
        button.setBackground(primary ? new Color(66, 84, 170) : new Color(37, 49, 70));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(70, 88, 122)),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        return button;
    }

    private void scheduleUiDrain() {
        synchronized (this) {
            if (uiUpdateScheduled) return;
            uiUpdateScheduled = true;
        }
        SwingUtilities.invokeLater(() -> {
            synchronized (ConsoleWindow.this) {
                uiUpdateScheduled = false;
            }
            if (textPane == null || frame == null || !windowVisible || paused) {
                pendingUiLines.clear();
                return;
            }
            LogLine line;
            while ((line = pendingUiLines.poll()) != null) {
                if (isAllowed(line)) appendLogLine(line.text());
            }
            updateStatus();
            highlightSearch();
            scrollToBottomIfEnabled();
        });
    }

    private boolean isAllowed(LogLine line) {
        JCheckBox filter = levelFilters.get(line.level());
        // Before the window is built, retain all levels in history.
        return filter == null || filter.isSelected();
    }

    private void rebuildDocument() {
        if (textPane == null) return;
        pendingUiLines.clear();
        StyledDocument document = textPane.getStyledDocument();
        try {
            document.remove(0, document.getLength());
        } catch (BadLocationException ignored) {
            return;
        }

        List<LogLine> copy;
        synchronized (history) {
            copy = new ArrayList<>(history);
        }
        for (LogLine line : copy) {
            if (isAllowed(line)) appendLogLine(line.text());
        }
        updateStatus();
        highlightSearch();
        scrollToBottomIfEnabled();
    }

    private void appendLogLine(String line) {
        StyledDocument document = textPane.getStyledDocument();
        StyleState state = new StyleState();
        StringBuilder chunk = new StringBuilder();
        int index = 0;
        try {
            while (index < line.length()) {
                FormatToken token = parseToken(line, index);
                if (token == null) {
                    chunk.append(line.charAt(index++));
                    continue;
                }
                flushChunk(document, chunk, state);
                applyToken(state, token);
                index += token.length();
            }
            flushChunk(document, chunk, state);
            document.insertString(document.getLength(), "\n", attributes(state));
        } catch (BadLocationException ignored) {
            // A line can be dropped if a concurrent clear invalidates its position.
        }
    }

    private void flushChunk(StyledDocument document, StringBuilder chunk, StyleState state) throws BadLocationException {
        if (chunk.length() == 0) return;
        document.insertString(document.getLength(), chunk.toString(), attributes(state));
        chunk.setLength(0);
    }

    private AttributeSet attributes(StyleState state) {
        SimpleAttributeSet attributes = new SimpleAttributeSet();
        StyleConstants.setFontFamily(attributes, monospaceFont);
        StyleConstants.setFontSize(attributes, 13);
        StyleConstants.setForeground(attributes, state.foreground == null ? DEFAULT_TEXT : state.foreground);
        StyleConstants.setBold(attributes, state.bold);
        StyleConstants.setItalic(attributes, state.italic);
        StyleConstants.setUnderline(attributes, state.underline);
        StyleConstants.setStrikeThrough(attributes, state.strikethrough);
        return attributes;
    }

    private void applyToken(StyleState state, FormatToken token) {
        if (token.hexColor() != null) {
            state.foreground = token.hexColor();
            state.clearDecorations();
            return;
        }
        if (token.ansiCodes() != null) {
            applyAnsi(state, token.ansiCodes());
            return;
        }
        char code = Character.toLowerCase(token.code());
        if (code >= '0' && code <= '9' || code >= 'a' && code <= 'f') {
            int colorIndex = code <= '9' ? code - '0' : code - 'a' + 10;
            state.foreground = MINECRAFT_COLORS[colorIndex];
            state.clearDecorations();
            return;
        }
        switch (code) {
            case 'l' -> state.bold = true;
            case 'o' -> state.italic = true;
            case 'n' -> state.underline = true;
            case 'm' -> state.strikethrough = true;
            case 'r' -> state.reset();
            case 'k' -> state.obfuscated = true; // Kept as a formatting state; log text itself stays readable.
            default -> { }
        }
    }

    private void applyAnsi(StyleState state, String codes) {
        String[] parts = codes.split(";");
        for (int i = 0; i < parts.length; i++) {
            int code = parseInt(parts[i], 0);
            if (code == 0) state.reset();
            else if (code == 1) state.bold = true;
            else if (code == 3) state.italic = true;
            else if (code == 4) state.underline = true;
            else if (code == 9) state.strikethrough = true;
            else if (code == 39) state.foreground = DEFAULT_TEXT;
            else if (code >= 30 && code <= 37) state.foreground = ANSI_COLORS[code - 30];
            else if (code >= 90 && code <= 97) state.foreground = ANSI_BRIGHT_COLORS[code - 90];
            else if (code == 38 && i + 4 < parts.length && parseInt(parts[i + 1], -1) == 2) {
                int red = clamp(parseInt(parts[i + 2], 0));
                int green = clamp(parseInt(parts[i + 3], 0));
                int blue = clamp(parseInt(parts[i + 4], 0));
                state.foreground = new Color(red, green, blue);
                i += 4;
            } else if (code == 38 && i + 2 < parts.length && parseInt(parts[i + 1], -1) == 5) {
                state.foreground = ansi256(parseInt(parts[i + 2], 7));
                i += 2;
            }
        }
    }

    private static final Color[] ANSI_COLORS = {
            new Color(0, 0, 0), new Color(170, 0, 0), new Color(0, 170, 0), new Color(170, 85, 0),
            new Color(0, 0, 170), new Color(170, 0, 170), new Color(0, 170, 170), new Color(170, 170, 170)
    };
    private static final Color[] ANSI_BRIGHT_COLORS = {
            new Color(85, 85, 85), new Color(255, 85, 85), new Color(85, 255, 85), new Color(255, 255, 85),
            new Color(85, 85, 255), new Color(255, 85, 255), new Color(85, 255, 255), new Color(255, 255, 255)
    };

    private Color ansi256(int index) {
        index = Math.max(0, Math.min(255, index));
        if (index < 16) return index < 8 ? ANSI_COLORS[index] : ANSI_BRIGHT_COLORS[index - 8];
        if (index < 232) {
            int value = index - 16;
            int[] levels = {0, 95, 135, 175, 215, 255};
            return new Color(levels[value / 36], levels[(value / 6) % 6], levels[value % 6]);
        }
        int gray = 8 + (index - 232) * 10;
        return new Color(gray, gray, gray);
    }

    private static int clamp(int value) { return Math.max(0, Math.min(255, value)); }
    private static int parseInt(String value, int fallback) {
        try { return Integer.parseInt(value); } catch (NumberFormatException ignored) { return fallback; }
    }

    private FormatToken parseToken(String text, int index) {
        char marker = text.charAt(index);
        if (marker == '\u001B' && index + 2 < text.length() && text.charAt(index + 1) == '[') {
            int end = text.indexOf('m', index + 2);
            if (end > index && end - index <= 40) {
                String codes = text.substring(index + 2, end);
                if (codes.matches("[0-9;]*")) return FormatToken.ansi(end - index + 1, codes.isEmpty() ? "0" : codes);
            }
            return null;
        }
        if (marker != '&' && marker != '\u00A7') return null;
        if (index + 1 >= text.length()) return null;

        char next = Character.toLowerCase(text.charAt(index + 1));
        if (next == '#' && index + 8 <= text.length()) {
            String hex = text.substring(index + 2, index + 8);
            if (isHex(hex)) return FormatToken.hex(8, new Color(Integer.parseInt(hex, 16)));
        }
        if (next == 'x') {
            String hex = parseRepeatedHex(text, index, marker);
            if (hex != null) return FormatToken.hex(14, new Color(Integer.parseInt(hex, 16)));
        }
        if ("0123456789abcdefklmnor".indexOf(next) >= 0) return FormatToken.code(2, next);
        return null;
    }

    private String parseRepeatedHex(String text, int index, char marker) {
        if (index + 14 > text.length()) return null;
        StringBuilder hex = new StringBuilder(6);
        for (int i = 0; i < 6; i++) {
            int markerPosition = index + 2 + i * 2;
            int digitPosition = markerPosition + 1;
            if (text.charAt(markerPosition) != marker || !isHexDigit(text.charAt(digitPosition))) return null;
            hex.append(text.charAt(digitPosition));
        }
        return hex.toString();
    }

    private boolean isHex(String value) {
        for (int i = 0; i < value.length(); i++) if (!isHexDigit(value.charAt(i))) return false;
        return true;
    }

    private boolean isHexDigit(char value) {
        return Character.digit(value, 16) >= 0;
    }

    private void highlightSearch() {
        if (textPane == null || searchField == null) return;
        var highlighter = textPane.getHighlighter();
        highlighter.removeAllHighlights();
        String query = searchField.getText().trim();
        if (query.isEmpty()) return;
        String fullText;
        try {
            fullText = textPane.getDocument().getText(0, textPane.getDocument().getLength());
        } catch (BadLocationException ignored) {
            return;
        }
        String lowerText = fullText.toLowerCase(java.util.Locale.ROOT);
        String lowerQuery = query.toLowerCase(java.util.Locale.ROOT);
        int from = 0;
        while ((from = lowerText.indexOf(lowerQuery, from)) >= 0) {
            try {
                highlighter.addHighlight(from, from + lowerQuery.length(),
                        new DefaultHighlighter.DefaultHighlightPainter(new Color(108, 91, 35, 150)));
            } catch (BadLocationException ignored) {
                break;
            }
            from += lowerQuery.length();
        }
    }

    private void togglePause() {
        paused = !paused;
        pauseButton.setText(paused ? "Продолжить" : "Пауза");
        if (!paused) rebuildDocument();
        updateStatus();
    }

    private void clearHistory() {
        synchronized (history) { history.clear(); }
        pendingUiLines.clear();
        rebuildDocument();
    }

    private void copyVisible() {
        if (textPane == null) return;
        try {
            String text = textPane.getDocument().getText(0, textPane.getDocument().getLength());
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(text), null);
            statusLabel.setText("Скопировано");
        } catch (Exception exception) {
            statusLabel.setText("Не удалось скопировать");
        }
    }

    private void scrollToBottomIfEnabled() {
        if (autoScrollCheck == null || !autoScrollCheck.isSelected() || textPane == null) return;
        textPane.setCaretPosition(textPane.getDocument().getLength());
    }

    private void updateStatus() {
        if (statusLabel == null) return;
        int count;
        synchronized (history) { count = history.size(); }
        statusLabel.setText((paused ? "PAUSED" : "LIVE") + "  •  " + count + " строк");
        statusLabel.setForeground(paused ? new Color(255, 196, 90) : new Color(92, 222, 160));
    }

    private Color colorForLevel(LogLine.Level level) {
        return switch (level) {
            case TRACE, DEBUG -> new Color(150, 165, 188);
            case INFO -> new Color(110, 190, 255);
            case WARN -> new Color(255, 196, 90);
            case ERROR, FATAL -> new Color(255, 110, 125);
            case OTHER -> MUTED;
        };
    }

    private record FormatToken(int length, char code, Color hexColor, String ansiCodes) {
        static FormatToken code(int length, char code) { return new FormatToken(length, code, null, null); }
        static FormatToken hex(int length, Color color) { return new FormatToken(length, '\0', color, null); }
        static FormatToken ansi(int length, String codes) { return new FormatToken(length, '\0', null, codes); }
    }

    private static final class StyleState {
        Color foreground;
        boolean bold;
        boolean italic;
        boolean underline;
        boolean strikethrough;
        boolean obfuscated;

        void clearDecorations() {
            bold = false;
            italic = false;
            underline = false;
            strikethrough = false;
            obfuscated = false;
        }

        void reset() {
            foreground = DEFAULT_TEXT;
            clearDecorations();
        }
    }
}
